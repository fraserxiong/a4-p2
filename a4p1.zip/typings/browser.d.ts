/// <reference path="browser/ambient/es6-shim/es6-shim.d.ts" />
/// <reference path="browser/ambient/jasmine/jasmine.d.ts" />
