import { Component }       from 'angular2/core';

@Component(
{
	selector: "custom-footer",
	templateUrl: "app/app-footer.component.html"
})

export class AppFooterComponent{

}
