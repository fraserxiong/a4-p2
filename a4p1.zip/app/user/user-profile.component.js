System.register(['angular2/core', 'angular2/router', './user.service', '../app-footer.component', '../app-header.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, user_service_1, app_footer_component_1, app_header_component_1;
    var UserProfileComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (user_service_1_1) {
                user_service_1 = user_service_1_1;
            },
            function (app_footer_component_1_1) {
                app_footer_component_1 = app_footer_component_1_1;
            },
            function (app_header_component_1_1) {
                app_header_component_1 = app_header_component_1_1;
            }],
        execute: function() {
            UserProfileComponent = (function () {
                function UserProfileComponent(_db, _routeParams) {
                    this._db = _db;
                    this._routeParams = _routeParams;
                }
                UserProfileComponent.prototype.get_user = function () {
                    return this.cur_user;
                };
                UserProfileComponent.prototype.ngOnInit = function () {
                    this.id = +this._routeParams.get('id');
                    this.user_list = this._db.get_list();
                    for (var i = 0; i < this.user_list.length; i++) {
                        var u_obj = this.user_list[i];
                        if (u_obj.id == this.id) {
                            this.cur_user = u_obj;
                            this.user_list = this.user_list.slice(i + 1, this.user_list.length);
                            return;
                        }
                    }
                };
                UserProfileComponent = __decorate([
                    core_1.Component({
                        selector: 'user',
                        templateUrl: "app/user/user-profile.component.html",
                        styleUrls: ['app/user/user-profile.component.css'],
                        directives: [app_header_component_1.AppHeaderComponent, app_footer_component_1.AppFooterComponent],
                        providers: [user_service_1.user_db]
                    }), 
                    __metadata('design:paramtypes', [user_service_1.user_db, router_1.RouteParams])
                ], UserProfileComponent);
                return UserProfileComponent;
            }());
            exports_1("UserProfileComponent", UserProfileComponent);
        }
    }
});
//# sourceMappingURL=user-profile.component.js.map