import {bootstrap} from 'angular2/platform/browser';
import {AppRouterComponent} from './app-router.component';

bootstrap(AppRouterComponent);
