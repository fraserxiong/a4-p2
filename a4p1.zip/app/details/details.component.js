System.register(['angular2/core', '../app-footer.component', '../app-offer.service', 'angular2/router', '../app-header.component'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, app_footer_component_1, app_offer_service_1, router_1, app_header_component_1;
    var DetailsComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (app_footer_component_1_1) {
                app_footer_component_1 = app_footer_component_1_1;
            },
            function (app_offer_service_1_1) {
                app_offer_service_1 = app_offer_service_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (app_header_component_1_1) {
                app_header_component_1 = app_header_component_1_1;
            }],
        execute: function() {
            DetailsComponent = (function () {
                function DetailsComponent(_offerService, _router, _routeParams) {
                    this._offerService = _offerService;
                    this._router = _router;
                    this._routeParams = _routeParams;
                    this.item = {
                        id: 0,
                        url: "dummy",
                        location: "dummy",
                        description: "dummy",
                        name: "dummy",
                        categories: [],
                        price: 0
                    };
                    this.related = [];
                    this.comments = [];
                }
                DetailsComponent.prototype.ngOnInit = function () {
                    var _this = this;
                    this._offerService.get_post_details(this.get_id())
                        .then(function (result) { return _this.item = result; });
                    this._offerService.get_related_posts(this.get_id())
                        .then(function (related) { return _this.related = related; });
                    this._offerService.get_comments_for_post(this.get_id())
                        .then(function (comments) { return _this.comments = comments; });
                };
                DetailsComponent.prototype.get_id = function () {
                    return decodeURIComponent(this._routeParams.get("id"));
                };
                DetailsComponent = __decorate([
                    core_1.Component({
                        selector: "post-details",
                        templateUrl: "app/details/details.component.html",
                        styleUrls: ["css/details.css", "css/common.css"],
                        directives: [app_header_component_1.AppHeaderComponent, app_footer_component_1.AppFooterComponent],
                        providers: [app_offer_service_1.AppOfferService]
                    }), 
                    __metadata('design:paramtypes', [app_offer_service_1.AppOfferService, router_1.Router, router_1.RouteParams])
                ], DetailsComponent);
                return DetailsComponent;
            }());
            exports_1("DetailsComponent", DetailsComponent);
        }
    }
});
//# sourceMappingURL=details.component.js.map