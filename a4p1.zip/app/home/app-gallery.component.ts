import { Component}       from 'angular2/core';

@Component(
{
	selector: 'home-gallery',
	templateUrl: 'app/home/app-gallery.component.html'
})

export class AppGalleryComponent{
}